 - Dec. 14th
	By now, this is the first third-party extension aka. mod for Cyberpunk 2077 and modding the Game is still very experimental. However
	using this Rich Presence for Discord shouldn't break the Game or decrease its stability.

RESET TO DEFAULTS:
	If you want to use the default configuration (without this Mod) again, simply copy the "launcher-configuration.json" from "Cyberpunk 2077/mods/richpresence/Defaults" into the "Cyberpunk 2077"
	Main Folder (The one with the "REDprelauncher.exe").

For more INFO, ISSUES or PULL REQUESTS head over to
	https://github.com/angelsflyinhell/Cyberpunk2077-RPC